package com.psaassessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PsaAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsaAssessmentApplication.class, args);
	}

}
